setwd("C:\\Users\\donac\\OneDrive\\Desktop\\ps lab\\IT24102677")

##Exercise

#1
y <- rnorm(25, mean = 45, sd = 2)
print(y)

#2
t.test(y, mu = 46, alternative = "less")
