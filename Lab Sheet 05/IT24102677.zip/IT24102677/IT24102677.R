setwd("C:\\Users\\IT24102677\\Desktop\\IT24102677\\IT24102677")


 
#1
Delivery_Times <- read.table("Exercise_Lab 05.txt", header = TRUE, sep = ",")
attach(Delivery_Times)
names(Delivery_Times)<-c("x1")
attach(Delivery_Times)

#2
hist(x1,
     breaks = seq(20, 70, length.out = 10),
     right = FALSE,
     main = "Histogram of Delivery Times")

#3 - symmetric distribution


#4
breaks <- seq(20, 70, length.out = 10)
hist_data <- hist(x1, breaks = breaks, plot = FALSE, right = FALSE)
cum_freq <- cumsum(hist_data$counts)

plot(breaks[-1], cum_freq,
     type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     pch = 16)
